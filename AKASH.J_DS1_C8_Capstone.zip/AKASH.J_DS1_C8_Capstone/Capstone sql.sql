USE  football;


-- What are the top 5 clubs with the highest average market value of player contracts in each season?
SELECT
    home_club_name,
    season,
    AVG(market_value_in_eur) AS avg_market_value
FROM Football_data_merged_cleaned
GROUP BY home_club_name, season
ORDER BY avg_market_value DESC LIMIT 5;



-- Who are the top 5 referees with the highest average yellow cards per game?
SELECT
    referee,
    COUNT(DISTINCT game_id) AS total_games,
    SUM(yellow_cards) / COUNT(DISTINCT game_id) AS avg_yellow_cards_per_game
FROM Football_data_merged_cleaned
GROUP BY referee
ORDER BY avg_yellow_cards_per_game DESC LIMIT 5;

